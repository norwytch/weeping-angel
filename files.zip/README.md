# triage — content-aware, transparent, downgrade-only

`response.confidence()` scores a file by *counting* corroborating rules. It can't
read the *content* of the evidence: who performed the `setinfo`, which direction
the time moved, whether the forged `$SI` is suspiciously round. This package adds
exactly that, and nothing more.

## Why it isn't an LLM

The framework is pure-stdlib and already has an ES-learned policy (`learn.py`).
The triage gap is a small classification problem over a handful of evidence
features, not an open-ended reasoning task — so it's the same shape as
`LearnedBlue`: a feature vector, one dot product, baked-in weights that work
untrained, optionally tuned by the existing Evolution Strategies loop. Per-feature
contributions are a more auditable "trace" than free text, with zero new deps and
full determinism.

## The safety invariant

Triage can only make the responder **more** cautious. `cap_decision` downgrades a
held action to `ALERT`; it never raises one. So the worst failure is a missed
auto-response a human still sees in the alert — never an autonomous escalation an
LLM talked itself into. The dangerous metric is therefore the **false-benign
rate** (holding a real stomp), which is what to gate eval on.

## Use

```python
from weeping_angel.triage import TriageScorer, gated_decide

scorer = TriageScorer()                 # default weights; or pass ES-trained ones
report = scorer.assess(file_id, findings, display_mace, setinfo_events, trusted_actors)
decision = gated_decide(policy, file_id, findings, report)   # caps, logs rationale
print(report.explain())
```

## Features (all benign-positive)

`actor_trusted`, `no_groundtruth_clash` (no R4), `corroboration` (−), 
`whole_second_si` (−), `rollback` (−). Fixed order; weights line up positionally,
like `learn._features`.

## Optional: one-line in-place integration

Instead of the `gated_decide` wrapper, add `triage: TriageReport | None = None` to
`ResponsePolicy.decide` and apply the same downgrade branch it already uses for
`protected_files`. The wrapper exists so the detector/response path stays
byte-identical when triage is absent.

## Next (only if linear features stop being enough)

If/when free-text evidence lands (`$LogFile` narratives, process trees from the
roadmap), the *same interface* (`assess -> TriageReport`) can be backed by a
heavier model. Swap the scorer, keep the invariant. Don't do this until the
features genuinely can't separate the cases.

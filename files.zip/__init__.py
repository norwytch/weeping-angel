"""Content-aware triage: a transparent linear scorer that reads the *evidence*
behind a finding (who, which direction, how round) and can only ever make the
response layer more cautious. Pure stdlib; same policy shape as ``learn``."""

from __future__ import annotations

from .features import FEATURE_NAMES, triage_features
from .integrate import cap_decision, gated_decide
from .report import Contribution, TriageReport
from .score import DEFAULT_WEIGHTS, TriageScorer

__all__ = [
    "TriageScorer",
    "TriageReport",
    "Contribution",
    "DEFAULT_WEIGHTS",
    "FEATURE_NAMES",
    "triage_features",
    "gated_decide",
    "cap_decision",
]

"""Glue: let triage cap a response, and *only* cap it.

This enforces the one invariant that makes the layer safe to ship: triage can
move an action *down* (toward caution) but never *up*. It reuses the exact
downgrade shape ``ResponsePolicy`` already applies to protected files, so the
behaviour is one the codebase already trusts.

Non-invasive: this wraps ``ResponsePolicy`` rather than editing it, so the
detector/response path is byte-identical when triage is absent. The one-line
alternative -- a ``triage=`` parameter on ``ResponsePolicy.decide`` -- is noted
in the package README.
"""

from __future__ import annotations

from collections.abc import Iterable

from ..detector import Finding
from ..response import Action, ResponseDecision, ResponsePolicy
from .report import TriageReport


def cap_decision(decision: ResponseDecision, report: TriageReport) -> ResponseDecision:
    """If triage recommends holding, downgrade anything above ALERT to ALERT.
    Never raises the action; returns the input unchanged otherwise."""
    if not report.recommend_hold or decision.action <= Action.ALERT:
        return decision
    return ResponseDecision(
        file_id=decision.file_id,
        action=Action.ALERT,
        confidence=decision.confidence,
        dry_run=decision.dry_run,
        executed=False,  # held: do not execute a downgraded-by-triage action
        rules=decision.rules,
        reason=(
            f"{decision.reason}; triage held ({report.disposition}, "
            f"benign_likelihood={report.benign_likelihood:.2f})"
        ),
    )


def gated_decide(
    policy: ResponsePolicy,
    file_id: str,
    findings: Iterable[Finding],
    report: TriageReport,
) -> ResponseDecision:
    """Run the normal policy, log the triage rationale, then cap the action.

    Order matters: the deterministic decision is computed first (triage can only
    constrain it), and the triage rationale is appended to the same ledger so the
    'why we backed off' is as auditable as the 'why we acted'.
    """
    findings = list(findings)
    decision = policy.decide(file_id, findings)
    if policy.ledger is not None:
        policy.ledger.append(report.to_event(), recorded_at=policy._now())
    return cap_decision(decision, report)
